module github.com/pion/stun/v3

go 1.24.0

require (
	github.com/pion/dtls/v3 v3.1.4
	github.com/pion/logging v0.2.4
	github.com/pion/transport/v4 v4.0.2
	github.com/stretchr/testify v1.11.1
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/wlynxg/anet v0.0.5 // indirect
	golang.org/x/crypto v0.48.0 // indirect
	golang.org/x/sys v0.41.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
