module github.com/pion/transport/v4

go 1.24.0

require (
	github.com/pion/logging v0.2.4
	github.com/stretchr/testify v1.11.1
	github.com/wlynxg/anet v0.0.5
	golang.org/x/net v0.34.0
	golang.org/x/sys v0.41.0
	golang.org/x/time v0.14.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
