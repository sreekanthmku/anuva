module github.com/pion/datachannel

require (
	github.com/pion/logging v0.2.4
	github.com/pion/sctp v1.10.0
	github.com/pion/transport/v4 v4.0.2
	github.com/stretchr/testify v1.11.1
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/pion/randutil v0.1.0 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

go 1.24.0
