// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package gcc

import (
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestClamp(t *testing.T) {
	tests := []struct {
		expected int
		x        int
		min      int
		max      int
	}{
		{
			expected: 50,
			x:        50,
			min:      0,
			max:      100,
		},
		{
			expected: 50,
			x:        50,
			min:      50,
			max:      100,
		},
		{
			expected: 100,
			x:        100,
			min:      0,
			max:      100,
		},
		{
			expected: 50,
			x:        3,
			min:      50,
			max:      100,
		},
		{
			expected: 100,
			x:        150,
			min:      0,
			max:      100,
		},
	}
	for i, tt := range tests {
		t.Run(fmt.Sprintf("int/%v", i), func(t *testing.T) {
			assert.Equal(t, tt.expected, clampInt(tt.x, tt.min, tt.max))
		})
		t.Run(fmt.Sprintf("duration/%v", i), func(t *testing.T) {
			x := time.Duration(tt.x)
			minVal := time.Duration(tt.min)
			maxVal := time.Duration(tt.max)
			expected := time.Duration(tt.expected)
			assert.Equal(t, expected, clampDuration(x, minVal, maxVal))
		})
	}
}
