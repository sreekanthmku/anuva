// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package handshake

import (
	"errors"

	"github.com/pion/dtls/v3/pkg/protocol"
)

// Typed errors.
var (
	errUnableToMarshalFragmented = &protocol.InternalError{
		Err: errors.New("unable to marshal fragmented handshakes"), //nolint:err113
	}
	errHandshakeMessageUnset = &protocol.InternalError{
		Err: errors.New("handshake message unset, unable to marshal"), //nolint:err113
	}
	errBufferTooSmall = &protocol.TemporaryError{
		Err: errors.New("buffer is too small"), //nolint:err113
	}
	errLengthMismatch = &protocol.InternalError{
		Err: errors.New("data length and declared length do not match"), //nolint:err113
	}
	errInvalidClientKeyExchange = &protocol.FatalError{
		Err: errors.New("unable to determine if ClientKeyExchange is a public key or PSK Identity"), //nolint:err113
	}
	errInvalidSignHashAlgorithm = &protocol.FatalError{
		Err: errors.New("invalid signature/hash algorithm"), //nolint:err113
	}
	errCookieTooLong = &protocol.FatalError{
		Err: errors.New("cookie must not be longer than 255 bytes"), //nolint:err113
	}
	errSessionIDTooLong = &protocol.FatalError{
		Err: errors.New("session ID must not be longer than 255 bytes"), //nolint:err113
	}
	errCertificateTypesTooLong = &protocol.FatalError{
		Err: errors.New("certificate types must not be longer than 255 entries"), //nolint:err113
	}
	errCompressionMethodsTooLong = &protocol.FatalError{
		Err: errors.New("compression methods must not be longer than 255 entries"), //nolint:err113
	}
	errPublicKeyTooLong = &protocol.FatalError{
		Err: errors.New("public key must not be longer than 255 bytes"), //nolint:err113
	}
	errInvalidEllipticCurveType = &protocol.FatalError{
		Err: errors.New("invalid or unknown elliptic curve type"), //nolint:err113
	}
	errInvalidNamedCurve = &protocol.FatalError{
		Err: errors.New("invalid named curve"), //nolint:err113
	}
	errCipherSuiteUnset = &protocol.FatalError{
		Err: errors.New("server hello can not be created without a cipher suite"), //nolint:err113
	}
	errCompressionMethodUnset = &protocol.FatalError{
		Err: errors.New("server hello can not be created without a compression method"), //nolint:err113
	}
	errInvalidCompressionMethod = &protocol.FatalError{
		Err: errors.New("invalid or unknown compression method"), //nolint:err113
	}
	errNotImplemented = &protocol.InternalError{
		Err: errors.New("feature has not been implemented yet"), //nolint:err113
	}
	errInvalidCertificateRequestContext = &protocol.FatalError{
		Err: errors.New("invalid certificate request context"), //nolint:err113
	}
	errInvalidCertificateEntry = &protocol.FatalError{
		Err: errors.New("invalid certificate entry"), //nolint:err113
	}
	errCertificateRequestContextTooLong = &protocol.FatalError{
		Err: errors.New("certificate request context must not be longer than 255 bytes"), //nolint:err113
	}
	errCertificateListTooLong = &protocol.FatalError{
		Err: errors.New("certificate list must not be longer than 2^24-1 bytes"), //nolint:err113
	}
	errInvalidExtensionsLength = &protocol.FatalError{
		Err: errors.New("extensions data must be between 2 and 2^16-1 bytes"), //nolint:err113
	}
	errMissingSignatureAlgorithmsExtension = &protocol.FatalError{
		Err: errors.New("signature_algorithms extension is required in CertificateRequest"), //nolint:err113
	}
)
