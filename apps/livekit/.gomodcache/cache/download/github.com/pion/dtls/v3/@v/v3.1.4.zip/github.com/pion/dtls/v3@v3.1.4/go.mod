module github.com/pion/dtls/v3

require (
	github.com/pion/logging v0.2.4
	github.com/pion/transport/v4 v4.0.1
	github.com/stretchr/testify v1.11.1
	golang.org/x/crypto v0.48.0
	golang.org/x/net v0.49.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/sys v0.41.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

go 1.24.0

// Retract version with broken RSA interop with OpenSSL DTLS 1.2.
retract v3.1.0

// Retract version with broken interoperability with firefox.
retract v3.1.3
