// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package extension

import (
	"encoding/binary"

	"github.com/pion/dtls/v3/pkg/crypto/elliptic"
)

const (
	supportedPointFormatsSize = 5
)

// SupportedPointFormats allows a Client/Server to negotiate
// the EllipticCurvePointFormats
//
// https://tools.ietf.org/html/rfc4492#section-5.1.2
type SupportedPointFormats struct {
	PointFormats []elliptic.CurvePointFormat
}

// TypeValue returns the extension TypeValue.
func (s SupportedPointFormats) TypeValue() TypeValue {
	return SupportedPointFormatsTypeValue
}

// Marshal encodes the extension.
func (s *SupportedPointFormats) Marshal() ([]byte, error) {
	if len(s.PointFormats) > 255 {
		return nil, errPointFormatsTooLarge
	}

	out := make([]byte, supportedPointFormatsSize)

	binary.BigEndian.PutUint16(out, uint16(s.TypeValue()))
	binary.BigEndian.PutUint16(out[2:], uint16(1+(len(s.PointFormats)))) //nolint:gosec // G115
	//nolint:gosec // G115: point format count is validated to be <= 255 above.
	out[4] = byte(len(s.PointFormats))

	for _, v := range s.PointFormats {
		out = append(out, byte(v)) //nolint:makezero // todo: fix
	}

	return out, nil
}

// Unmarshal populates the extension from encoded data.
func (s *SupportedPointFormats) Unmarshal(data []byte) error {
	if len(data) < supportedPointFormatsSize {
		return errBufferTooSmall
	}

	declaredLength := int(binary.BigEndian.Uint16(data[2:4]))
	pointFormatCount := int(data[4])

	switch {
	case TypeValue(binary.BigEndian.Uint16(data)) != s.TypeValue():
		return errInvalidExtensionType
	case declaredLength > len(data)-4: // type + declared length = 4
		return errLengthMismatch
	case supportedPointFormatsSize+pointFormatCount > len(data):
		return errLengthMismatch
	case pointFormatCount+1 != declaredLength:
		return errLengthMismatch
	}

	for i := range pointFormatCount {
		p := elliptic.CurvePointFormat(data[supportedPointFormatsSize+i])
		switch p {
		case elliptic.CurvePointFormatUncompressed:
			s.PointFormats = append(s.PointFormats, p)
		default:
		}
	}

	return nil
}
