// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package extension

import (
	"encoding/binary"

	"github.com/pion/dtls/v3/pkg/crypto/elliptic"
)

const (
	supportedGroupsHeaderSize = 6
)

// SupportedEllipticCurves allows a Client/Server to communicate
// what curves they both support
//
// https://tools.ietf.org/html/rfc8422#section-5.1.1
//
// In DTLS 1.3, this extension in renamed to "supported_groups".
// https://datatracker.ietf.org/doc/html/rfc8446#section-4.2.7
type SupportedEllipticCurves struct {
	EllipticCurves []elliptic.Curve
}

// TypeValue returns the extension TypeValue.
func (s SupportedEllipticCurves) TypeValue() TypeValue {
	return SupportedEllipticCurvesTypeValue
}

// Marshal encodes the extension.
func (s *SupportedEllipticCurves) Marshal() ([]byte, error) {
	out := make([]byte, supportedGroupsHeaderSize)

	binary.BigEndian.PutUint16(out, uint16(s.TypeValue()))
	binary.BigEndian.PutUint16(out[2:], uint16(2+(len(s.EllipticCurves)*2))) //nolint:gosec // G115
	binary.BigEndian.PutUint16(out[4:], uint16(len(s.EllipticCurves)*2))     //nolint:gosec // G115

	for _, v := range s.EllipticCurves {
		out = append(out, []byte{0x00, 0x00}...) //nolint:makezero // todo: fix
		binary.BigEndian.PutUint16(out[len(out)-2:], uint16(v))
	}

	return out, nil
}

// Unmarshal populates the extension from encoded data.
func (s *SupportedEllipticCurves) Unmarshal(data []byte) error {
	if len(data) < supportedGroupsHeaderSize {
		return errBufferTooSmall
	}

	declaredLength := int(binary.BigEndian.Uint16(data[2:4]))
	groupCount := int(binary.BigEndian.Uint16(data[4:]) / 2)

	switch {
	case TypeValue(binary.BigEndian.Uint16(data)) != s.TypeValue():
		return errInvalidExtensionType
	case declaredLength > len(data)-4: // type + declared length = 4
		return errLengthMismatch
	case supportedGroupsHeaderSize+(groupCount*2) > len(data):
		return errLengthMismatch
	case groupCount*2+2 != declaredLength:
		return errLengthMismatch
	}

	for i := range groupCount {
		supportedGroupID := elliptic.Curve(binary.BigEndian.Uint16(data[(supportedGroupsHeaderSize + (i * 2)):]))
		if _, ok := elliptic.Curves()[supportedGroupID]; ok {
			s.EllipticCurves = append(s.EllipticCurves, supportedGroupID)
		}
	}

	return nil
}
